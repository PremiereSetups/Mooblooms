package com.yanisbft.mooblooms.client;

import com.yanisbft.mooblooms.entity.MoobloomEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.CowEntityModel;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3f;

@Environment(EnvType.CLIENT)
public class MoobloomBlockStateRenderer<T extends MoobloomEntity> extends FeatureRenderer<T, CowEntityModel<T>> {

    private final BlockRenderManager blockRenderManager;

    public MoobloomBlockStateRenderer(FeatureRendererContext<T, CowEntityModel<T>> context, BlockRenderManager blockRenderManager) {
        super(context);
        this.blockRenderManager = blockRenderManager;
    }

    @Override
    public void render(MatrixStack matrixStack, VertexConsumerProvider vertexConsumers, int light, MoobloomEntity entity, float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {

        if (entity.isBaby())
            return;

        MinecraftClient minecraftClient = MinecraftClient.getInstance();
        boolean bl = minecraftClient.hasOutline(entity) && entity.isInvisible();

        if (entity.isInvisible() && !bl)
            return;

        BlockState blockState = entity.settings.getBlockState();
        Vec3f scale = entity.settings.getBlockStateRendererScale();
        Vec3d translation = entity.settings.getBlockStateRendererTranslation();
        int overlay = LivingEntityRenderer.getOverlay(entity, 0.0F);

        BakedModel bakedModel = this.blockRenderManager.getModel(blockState);
        matrixStack.push();
        matrixStack.translate(0.2f, -0.35f, 0.5);
        float degrees = entity.isSuncower() ? -78.0F : -48.0F;
        matrixStack.multiply(Vec3f.POSITIVE_Y.getDegreesQuaternion(degrees));
        matrixStack.scale(scale.getX(), scale.getY(), scale.getZ());
        matrixStack.translate(translation.getX(), translation.getY(), translation.getZ());
        this.renderMushroom(matrixStack, vertexConsumers, light, bl, blockState, overlay, bakedModel);
        matrixStack.pop();
        matrixStack.push();

        // Middle
        matrixStack.translate(0.2f, -0.35f, 0.5);
        matrixStack.multiply(Vec3f.POSITIVE_Y.getDegreesQuaternion(42.0f));
        matrixStack.translate(0.1f, 0.0, -0.6f);
        float sunCowerDegree = entity.isSuncower() ? -120.0F : -48.0F;
        matrixStack.multiply(Vec3f.POSITIVE_Y.getDegreesQuaternion(sunCowerDegree));
        matrixStack.scale(scale.getX(), scale.getY(), scale.getZ());
        matrixStack.translate(translation.getX(), translation.getY(), translation.getZ());
        this.renderMushroom(matrixStack, vertexConsumers, light, bl, blockState, overlay, bakedModel);
        matrixStack.pop();
        matrixStack.push();

        // Head
        this.getContextModel().getHead().rotate(matrixStack);
        matrixStack.translate(0.0, -0.7f, -0.2f);
        matrixStack.multiply(Vec3f.POSITIVE_Y.getDegreesQuaternion(-78.0f));
        matrixStack.scale(scale.getX(), scale.getY(), scale.getZ());
        matrixStack.translate(translation.getX(), translation.getY(), translation.getZ());
        this.renderMushroom(matrixStack, vertexConsumers, light, bl, blockState, overlay, bakedModel);
        matrixStack.pop();

    }

    private void renderMushroom(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, boolean renderAsModel, BlockState mushroomState, int overlay, BakedModel mushroomModel) {
        if (renderAsModel) {
            this.blockRenderManager.getModelRenderer().render(matrices.peek(), vertexConsumers.getBuffer(RenderLayer.getOutline(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE)), mushroomState, mushroomModel, 0.0f, 0.0f, 0.0f, light, overlay);
        } else {
            this.blockRenderManager.renderBlockAsEntity(mushroomState, matrices, vertexConsumers, light, overlay);
        }
    }

}
