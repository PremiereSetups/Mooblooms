package com.yanisbft.mooblooms.config;

public interface MoobloomConfigCategory {
}
