package com.yanisbft.mooblooms.api;

import com.yanisbft.mooblooms.config.MoobloomConfigCategory;
import com.yanisbft.mooblooms.entity.MoobloomEntity;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3f;
import net.minecraft.util.registry.Registry;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.google.common.base.Preconditions.checkState;

@SuppressWarnings("unchecked")
public class Moobloom extends AbstractMoobloom {

    public static final Map<EntityType<?>, Moobloom> MOOBLOOM_BY_TYPE = new HashMap<>();
    private final EntityType<MoobloomEntity> entityType;
    private SpawnEggItem spawnEgg;

    private Moobloom(Builder settings) {
        super(settings);

        FabricEntityTypeBuilder.Mob<?> builder = FabricEntityTypeBuilder.createMob()
                .entityFactory(MoobloomEntity::new)
                .spawnGroup(SpawnGroup.CREATURE)
                .dimensions(EntityDimensions.changing(0.9F, 1.4F))
                .trackRangeChunks(10)
                .defaultAttributes(MoobloomEntity::createCowAttributes);

        if (this.settings.fireImmune) {
            builder.fireImmune();
        }

        this.entityType = (EntityType<MoobloomEntity>) builder.build();

        Registry.register(Registry.ENTITY_TYPE, this.settings.name, this.entityType);

        if (this.settings.primarySpawnEggColor != 0 && this.settings.secondarySpawnEggColor != 0) {
            this.spawnEgg = new SpawnEggItem(this.entityType, this.settings.primarySpawnEggColor, this.settings.secondarySpawnEggColor, new Item.Settings().maxCount(64).group(this.settings.spawnEggItemGroup));
            Identifier itemName = new Identifier(this.settings.name.getNamespace(), this.settings.name.getPath() + "_spawn_egg");
            Registry.register(Registry.ITEM, itemName, this.spawnEgg);
        }

        if (this.settings.spawnEntry != null && this.isSpawnEnabled()) {
            BiomeModifications.addSpawn(this.settings.spawnEntry.getBiomeSelector(), SpawnGroup.CREATURE, this.entityType, this.settings.spawnEntry.getWeight(), this.settings.spawnEntry.getMinGroupSize(), this.settings.spawnEntry.getMaxGroupSize());
        }

        MOOBLOOM_BY_TYPE.putIfAbsent(this.entityType, this);
    }

    public EntityType<MoobloomEntity> getEntityType() {
        return this.entityType;
    }

    public SpawnEggItem getSpawnEgg() {
        return this.spawnEgg;
    }

    public static class Builder extends AbstractMoobloom.Builder {

        public Builder() {
            super(EntityType.COW.getLootTableId());
        }

        /**
         * Sets the name of this moobloom.
         *
         * @param name an {@linkplain Identifier}, consisting of a namespace and a path
         * @return this builder for chaining
         */
        public Builder name(Identifier name) {
            this.name = name;
            return this;
        }

        /**
         * Sets the block state related to this moobloom.
         * <p>Will appear on this moobloom's back and be randomly placed on valid blocks.</p>
         * <p>The item matching the block state will be dropped when shearing this moobloom.</p>
         *
         * @param state a block state
         * @return this builder for chaining
         */
        public Builder blockState(BlockState state) {
            this.blockState = state;
            return this;
        }

        /**
         * Sets how the block state of this moobloom will be rendered on its back.
         *
         * @param scaleX       the scale on the X axis
         * @param scaleY       the scale on the Y axis
         * @param scaleZ       the scale on the Z axis
         * @param translationX the translation on the X axis
         * @param translationY the translation on the Y axis
         * @param translationZ the translation on the Z axis
         * @return this builder for chaining
         */
        public Builder blockStateRenderer(float scaleX, float scaleY, float scaleZ, double translationX, double translationY, double translationZ) {
            return this.blockStateRenderer(new Vec3f(scaleX, scaleY, scaleZ), new Vec3d(translationX, translationY, translationZ));
        }

        /**
         * Sets how the block state of this moobloom will be rendered on its back.
         *
         * @param scale       a vector representing the scale
         * @param translation a vector representing the translation
         * @return this builder for chaining
         */
        public Builder blockStateRenderer(Vec3f scale, Vec3d translation) {
            this.blockStateRendererScale = scale;
            this.blockStateRendererTranslation = translation;
            return this;
        }

        /**
         * Sets this moobloom to be fire immune.
         *
         * @return this builder for chaining
         */
        public Builder fireImmune() {
            this.fireImmune = true;
            return this;
        }

        /**
         * Sets the blocks that are valid for placing the specified {@linkplain #blockState(BlockState)}.
         *
         * @param blocks a list of blocks
         * @return this builder for chaining
         */
        public Builder validBlocks(List<Block> blocks) {
            this.validBlocks = blocks;
            return this;
        }

        /**
         * Sets this moobloom to be unable to place blocks.
         *
         * @return this builder for chaining
         */
        public Builder cannotPlaceBlocks() {
            this.canPlaceBlocks = false;
            return this;
        }

        /**
         * Sets the status effects that will not affect this moobloom.
         *
         * @param effects a list of status effects
         * @return this builder for chaining
         */
        public Builder ignoredEffects(List<StatusEffect> effects) {
            this.ignoredEffects = effects;
            return this;
        }

        /**
         * Sets the damage sources that will not affect this moobloom.
         *
         * @param damageSources a list of damage sources
         * @return this builder for chaining
         */
        public Builder ignoredDamageSources(List<DamageSource> damageSources) {
            this.ignoredDamageSources = damageSources;
            return this;
        }

        /**
         * Sets the particle constantly displayed around this moobloom.
         *
         * @param particle a particle effect
         * @return this builder for chaining
         */
        public Builder particle(ParticleEffect particle) {
            this.particle = particle;
            return this;
        }

        /**
         * Sets the loot table of this moobloom.
         * <p>Defaults to {@linkplain net.minecraft.entity.passive.CowEntity cow's} loot table.</p>
         *
         * @param lootTable a loot table {@linkplain Identifier identifier}
         * @return this builder for chaining
         */
        public Builder lootTable(Identifier lootTable) {
            this.lootTable = lootTable;
            return this;
        }

        /**
         * Sets the spawn entry used to generate this moobloom.
         *
         * @param spawnEntry a {@linkplain SpawnEntry spawn entry}
         * @return this builder for chaining
         */
        public Builder spawnEntry(SpawnEntry spawnEntry) {
            this.spawnEntry = spawnEntry;
            return this;
        }

        /**
         * Sets this moobloom's spawn egg colors.
         * <p>Will appear in {@linkplain ItemGroup#MISC}.</p>
         *
         * @param primaryColor   an int representing the main color
         * @param secondaryColor an int representing the dots' color
         * @return this builder for chaining
         */
        public Builder spawnEgg(int primaryColor, int secondaryColor) {
            return this.spawnEgg(primaryColor, secondaryColor, ItemGroup.MISC);
        }

        /**
         * Sets this moobloom's spawn egg colors and item group.
         *
         * @param primaryColor   an int representing the main color
         * @param secondaryColor an int representing the dots' color
         * @param group          an item group
         * @return this builder for chaining
         */
        public Builder spawnEgg(int primaryColor, int secondaryColor, ItemGroup group) {
            this.primarySpawnEggColor = primaryColor;
            this.secondarySpawnEggColor = secondaryColor;
            this.spawnEggItemGroup = group;
            return this;
        }

        /**
         * Sets this moobloom's config category.
         * <p>Will be used to get the {@code spawnBlocks} config option.</p>
         *
         * @param configCategory an instance of a class implementing {@link MoobloomConfigCategory}
         * @return this builder for chaining
         */
        public Builder configCategory(MoobloomConfigCategory configCategory) {
            this.configCategory = configCategory;
            return this;
        }

        /**
         * Creates the moobloom.
         *
         * @return a new {@linkplain Moobloom}
         */
        public Moobloom build() {
            checkState(this.name != null, "A name is required to build a new moobloom.");
            checkState(this.blockState != null, "A block state is required to build a new moobloom.");
            return new Moobloom(this);
        }
    }
}
